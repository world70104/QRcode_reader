/*
 * QRCodeReader.swift
 *
 * Copyright 2014-present Yannick Loriot.
 * http://yannickloriot.com
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */

import UIKit

/// Overlay over the camera view to display the area (a square) where to scan the code.
public final class ReaderOverlayView: UIView {
    // corner width
    let cornerWidth = 30.0
    var timerTest : Timer?
    var scanLineHigh = 0
    var scanLineMaxHigh = 100000
    var innerRect = CGRect(x: 0, y: 0, width: 0, height: 0)
    
    var acc_x : Double = 0.0
    var temp_x : Double = 0.0
    var i: CGFloat = 0
    
    //pragma mark - scan line
    let VIEW_SCAN_LINE_TAG = 1111;
//    var scanLineView:UIImageView!

  private var overlay: CAShapeLayer = {
    var overlay             = CAShapeLayer()
    overlay.backgroundColor = UIColor.green.cgColor
    overlay.fillColor       = UIColor.clear.cgColor
    overlay.strokeColor     = UIColor(red: 227/255, green: 181/255, blue: 61/255, alpha: 1.0).cgColor
    overlay.lineWidth       = 3
//    overlay.lineDashPattern = [255.0, 255.0]
    overlay.lineDashPhase   = 0

    return overlay
  }()

  override init(frame: CGRect) {
    super.init(frame: frame)

    setupOverlay()
//    startTimer()
    scanlineCreate()
    scanlineStart()
    scanLineHigh = 0
  }

  required public init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)

    setupOverlay()
//    startTimer()
    scanlineCreate()
    scanlineStart()
    scanLineHigh = 0
  }

  private func setupOverlay() {
    layer.addSublayer(overlay)
  }

  var overlayColor: UIColor = UIColor.white {
    didSet {
      self.overlay.strokeColor = overlayColor.cgColor
      
      self.setNeedsDisplay()
    }
  }

    public override func draw(_ rect: CGRect) {
/*
    innerRect = rect.insetBy(dx: 50, dy: 50)
    let minSize   = min(innerRect.width, innerRect.height)

    if innerRect.width != minSize {
      innerRect.origin.x   += (innerRect.width - minSize) / 2
      innerRect.size.width = minSize
    }
    else if innerRect.height != minSize {
      innerRect.origin.y    += (innerRect.height - minSize) / 2
      innerRect.size.height = minSize
    }
*/
    let linePath = UIBezierPath()
    // left top
    linePath.move(to: CGPoint(x: innerRect.origin.x, y: innerRect.origin.y))
    linePath.addLine(to: CGPoint(x: innerRect.origin.x + CGFloat(cornerWidth), y: innerRect.origin.y))
    linePath.move(to: CGPoint(x: innerRect.origin.x, y: innerRect.origin.y))
    linePath.addLine(to: CGPoint(x: innerRect.origin.x, y: innerRect.origin.y + CGFloat(cornerWidth)))
    // right top
    linePath.move(to: CGPoint(x: innerRect.origin.x + innerRect.width, y: innerRect.origin.y))
    linePath.addLine(to: CGPoint(x: innerRect.origin.x + innerRect.width - CGFloat(cornerWidth), y: innerRect.origin.y))
    linePath.move(to: CGPoint(x: innerRect.origin.x + innerRect.width, y: innerRect.origin.y))
    linePath.addLine(to: CGPoint(x: innerRect.origin.x + innerRect.width, y: innerRect.origin.y + CGFloat(cornerWidth)))
    // left bottom
    linePath.move(to: CGPoint(x: innerRect.origin.x, y: innerRect.origin.y + innerRect.height))
    linePath.addLine(to: CGPoint(x: innerRect.origin.x + CGFloat(cornerWidth), y: innerRect.origin.y + innerRect.height))
    linePath.move(to: CGPoint(x: innerRect.origin.x, y: innerRect.origin.y + innerRect.height))
    linePath.addLine(to: CGPoint(x: innerRect.origin.x, y: innerRect.origin.y + innerRect.height - CGFloat(cornerWidth)))
    // right bottom
    linePath.move(to: CGPoint(x: innerRect.origin.x + innerRect.width, y: innerRect.origin.y + innerRect.height))
    linePath.addLine(to: CGPoint(x: innerRect.origin.x + innerRect.width - CGFloat(cornerWidth),
            y: innerRect.origin.y + innerRect.height))
    linePath.move(to: CGPoint(x: innerRect.origin.x + innerRect.width, y: innerRect.origin.y + innerRect.height))
    linePath.addLine(to: CGPoint(x: innerRect.origin.x + innerRect.width,
            y: innerRect.origin.y + innerRect.height - CGFloat(cornerWidth)))

    overlay.path = linePath.cgPath
/*
        // set the scan line
        let lineHigh = 3
        self.scanLineMaxHigh = Int(innerRect.height) - lineHigh * 2

        let accLine_x = UIGraphicsGetCurrentContext()
        accLine_x!.setLineWidth(2)
        accLine_x!.setStrokeColor(UIColor.red.cgColor)
        accLine_x!.move(
            to: CGPoint(x:Int(innerRect.origin.x), y:Int(innerRect.origin.y) + self.scanLineHigh + lineHigh))
        accLine_x!.addLine(
            to: CGPoint(x:Int(innerRect.origin.x + innerRect.width), y:Int(innerRect.origin.y) + self.scanLineHigh + lineHigh))
        accLine_x!.strokePath()
*/
    }
    
    public override func layoutSubviews() {
        super.layoutSubviews()
        
//        let scanLineView = self.viewWithTag(self.VIEW_SCAN_LINE_TAG) as! UIImageView
//        scanLineView.frame.origin.y = innerRect.origin.y + 3
        
    }
    
    func scanlineCreate() {
        let screenSize = UIScreen.main.bounds
        innerRect = screenSize.insetBy(dx: 50, dy: 50)
        let minSize   = min(innerRect.width, innerRect.height)
        if innerRect.width != minSize {
            innerRect.origin.x   += (innerRect.width - minSize) / 2
            innerRect.size.width = minSize
        }
        else if innerRect.height != minSize {
            innerRect.origin.y    += (innerRect.height - minSize) / 2
            innerRect.size.height = minSize
        }
        
        let scanLineView = UIImageView(frame: CGRect(
            x:innerRect.origin.x + 3,
            y:innerRect.origin.y - 20,
            width:innerRect.size.width-6,
            height:50))
        scanLineView.tag = VIEW_SCAN_LINE_TAG
        scanLineView.contentMode = .scaleToFill
        scanLineView.image = UIImage(named: "scanline.png")
        scanLineView.isHidden = true
//        scanLineView.frame.origin.y = innerRect.origin.y + 3
        addSubview(scanLineView)
    }

    func scanlineStart() {
        DispatchQueue.main.async {
            let scanLineView = self.viewWithTag(self.VIEW_SCAN_LINE_TAG) as! UIImageView
//            if scanLineView != nil {
                scanLineView.isHidden = false
//                let frame = UIScreen.main.bounds
                let animation = CABasicAnimation(keyPath: "position" )
//            animation.toValue = NSValue(cgPoint: CGPoint(x:scanLineView.center.x, y:frame.size.height));
                animation.toValue = NSValue(cgPoint: CGPoint(x:scanLineView.center.x,
                    y:self.innerRect.size.height - 6 + self.innerRect.origin.y));
                animation.autoreverses = false //  YES;
                animation.duration = 3.0;
                animation.repeatCount = Float.infinity //HUGE_VAL;
                animation.isRemovedOnCompletion = false //NO;
                animation.fillMode = kCAFillModeForwards;
                scanLineView.layer.add(animation, forKey:"position");
            
//                scanLineView.frame.origin.y = self.innerRect.origin.y + 3
//            }
        }
    }

    func scanlineStop() {
        DispatchQueue.main.async {
            let scanLineView = self.viewWithTag(self.VIEW_SCAN_LINE_TAG) as! UIImageView
//            if let scanLineView = self.viewWithTag(self.VIEW_SCAN_LINE_TAG) as! UIImageView {
            scanLineView.isHidden = true
            scanLineView.layer.removeAllAnimations();
//            }
        }
    }
}
